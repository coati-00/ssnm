from setuptools import setup, find_packages

setup(
    name="windloginfilter",
    version="0.5.3",
    description="cherrypy filter for doing WIND authentication",
    author="Anders Pearson",
    author_email="anders@columbia.edu",
    url="http://www.ccnmtl.columbia.edu/",
    zip_safe=False,
    packages=find_packages(),
    )
